#!/usr/bin/env bash
set -euo pipefail

INPUT="${1:?Arquivo de entrada não informado}"
OUTPUT="${2:?Arquivo de saída não informado}"
RESOLUTION="${3:-1080p}"
PROFILE="${4:-quality}"
CODEC="${5:-h265}"
CRF="${6:-19}"

case "$RESOLUTION" in
  1080p)
    WIDTH=1920
    HEIGHT=1080
    ;;
  720p)
    WIDTH=1280
    HEIGHT=720
    ;;
  *)
    echo "Resolução inválida: $RESOLUTION"
    exit 1
    ;;
esac

# Preserva a proporção original. Conteúdo 4:3, por exemplo, recebe barras laterais
# em vez de ser esticado artificialmente para 16:9.
SCALE_FILTER="scale=${WIDTH}:${HEIGHT}:force_original_aspect_ratio=decrease:flags=lanczos+accurate_rnd+full_chroma_int,pad=${WIDTH}:${HEIGHT}:(ow-iw)/2:(oh-ih)/2:black"

case "$PROFILE" in
  fast)
    # Limpeza leve + upscale Lanczos + nitidez discreta.
    VF="hqdn3d=1.0:1.0:4.0:4.0,${SCALE_FILTER},unsharp=5:5:0.25:5:5:0.0"
    PRESET_H264="veryfast"
    PRESET_H265="veryfast"
    ;;
  quality)
    # Limpeza mais forte de ruído/compressão, redução de banding, upscale e nitidez moderada.
    VF="hqdn3d=1.5:1.5:6.0:6.0,deband=1thr=0.018:2thr=0.018:3thr=0.018:4thr=0.018:range=16:blur=true,${SCALE_FILTER},unsharp=5:5:0.40:5:5:0.0"
    PRESET_H264="fast"
    PRESET_H265="fast"
    ;;
  *)
    echo "Perfil inválido: $PROFILE"
    exit 1
    ;;
esac

case "$CODEC" in
  h265)
    VCODEC="libx265"
    PRESET="$PRESET_H265"
    EXTRA_VIDEO=( -tag:v hvc1 )
    ;;
  h264)
    VCODEC="libx264"
    PRESET="$PRESET_H264"
    EXTRA_VIDEO=( -pix_fmt yuv420p )
    ;;
  *)
    echo "Codec inválido: $CODEC"
    exit 1
    ;;
esac

mkdir -p "$(dirname "$OUTPUT")"

echo "========================================"
echo "Entrada    : $INPUT"
echo "Saída      : $OUTPUT"
echo "Resolução  : $RESOLUTION (${WIDTH}x${HEIGHT})"
echo "Perfil     : $PROFILE"
echo "Codec      : $CODEC"
echo "CRF        : $CRF"
echo "========================================"

# Mapeia o primeiro vídeo, todos os áudios e todas as legendas quando existirem.
# Áudio e legendas são copiados sem recompressão sempre que possível.
ffmpeg -hide_banner -y \
  -i "$INPUT" \
  -map 0:v:0 \
  -map 0:a? \
  -map 0:s? \
  -map_metadata 0 \
  -vf "$VF" \
  -c:v "$VCODEC" \
  -preset "$PRESET" \
  -crf "$CRF" \
  "${EXTRA_VIDEO[@]}" \
  -c:a copy \
  -c:s copy \
  "$OUTPUT"

echo "Processamento concluído."
