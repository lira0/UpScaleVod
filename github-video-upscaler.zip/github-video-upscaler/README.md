# GitHub Video Upscaler — CPU

Workflow para melhorar um episódio por vez usando apenas um runner padrão do GitHub Actions.

> **Importante:** esta versão não usa IA generativa nem Real-ESRGAN. Ela usa restauração por filtros do FFmpeg + upscale Lanczos de alta qualidade. Isso foi escolhido porque é muito mais viável em CPU e mais confiável dentro do limite de execução do GitHub Actions.

## O que ele faz

1. Você abre **Actions** no repositório.
2. Escolhe **Video Upscaler - CPU**.
3. Clica em **Run workflow**.
4. Cola a URL direta do episódio.
5. Escolhe 720p ou 1080p, perfil Fast ou Quality, codec H.264/H.265 e CRF.
6. O GitHub baixa, processa e gera um `.mkv`.
7. No fim da execução, o arquivo aparece na seção **Artifacts**.

## Perfis

### Fast

- Redução leve de ruído.
- Upscale Lanczos.
- Nitidez discreta.
- Indicado para testar rapidamente e para fontes já razoáveis.

### Quality

- Redução mais forte de ruído e artefatos.
- Redução de banding.
- Upscale Lanczos preciso.
- Nitidez moderada.
- Mais lento, mas é o perfil recomendado para episódios SD comprimidos.

## Resolução e proporção

O workflow não estica vídeos 4:3.

Exemplo: um episódio `640x480` convertido para 1080p vira imagem aproximadamente `1440x1080` centralizada em um quadro `1920x1080`, com barras laterais. Isso evita deformar rostos e cenários.

## Codec

- `h265`: arquivo menor para qualidade semelhante, porém mais lento para codificar.
- `h264`: normalmente mais rápido e mais compatível.

Se o job estiver chegando perto do limite de tempo, teste primeiro:

- Profile: `fast`
- Codec: `h264`
- Resolution: `720p`

Depois aumente a qualidade gradualmente.

## CRF

Sugestões:

- `18`: qualidade alta / arquivo maior.
- `19`: excelente equilíbrio.
- `20-21`: arquivo menor.
- `22+`: compressão mais visível.

## Como instalar no GitHub

Crie um repositório e envie todo o conteúdo desta pasta mantendo exatamente esta estrutura:

```text
.github/
  workflows/
    upscale.yml
scripts/
  process-video.sh
README.md
```

Depois abra:

**Actions → Video Upscaler - CPU → Run workflow**

## Observações importantes

- O endereço fornecido precisa ser um **link direto** para o arquivo, acessível pelo runner.
- Links que exigem login, cookies ou tokens não funcionarão sem configuração adicional.
- Esta versão processa **um episódio por execução**.
- Se a fonte for muito ruim, 1080p não se torna magicamente Blu-ray; o objetivo é limpar a imagem, reduzir defeitos de compressão e fazer um upscale mais agradável.
- Arquivos muito grandes podem esbarrar em limites de espaço/tempo do runner ou de artifacts.

## Próxima evolução possível

Depois de testar o tempo de um episódio real, dá para criar uma segunda versão dividindo o episódio em partes e usando vários jobs do GitHub em paralelo. Também dá para adicionar um modo de super-resolution por IA em CPU, mas ele será consideravelmente mais lento.
